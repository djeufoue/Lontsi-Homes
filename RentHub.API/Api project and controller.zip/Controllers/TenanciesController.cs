using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RentHub.API.Data;
using RentHub.API.Models.Entities;
using Common.Enums;
using Common.CommunicationModels;
using System.Security.Claims;

namespace RentHub.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TenanciesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public TenanciesController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        /// <summary>
        /// Lists all tenancies for the current user.  Landlords see tenancies for their properties,
        /// tenants see their own tenancies, owners see tenancies for apartments they manage, and
        /// property managers see tenancies for properties they manage.
        /// </summary>
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetTenancies()
        {
            try
            {
                var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdClaim))
                {
                    return Unauthorized();
                }
                // Tenancies associated with the user in any capacity: landlord, tenant, member, owner or manager
                var tenancies = await _context.Tenancies
                    .Include(t => t.Apartment)
                    .ThenInclude(a => a.Property)
                    .Include(t => t.Members)
                    .Where(t =>
                        // Tenant (primary tenant or additional member)
                        t.TenantId == userIdClaim ||
                        t.Members.Any(m => m.MemberId == userIdClaim) ||
                        // Landlord
                        t.Apartment!.Property!.LandlordId == userIdClaim ||
                        // Owner assigned to this apartment
                        _context.ApartmentOwners.Any(o => o.ApartmentId == t.ApartmentId && o.OwnerId == userIdClaim) ||
                        // Manager assigned to the property
                        _context.PropertyManagerAssignments.Any(m => m.PropertyId == t.Apartment.PropertyId && m.ManagerId == userIdClaim)
                    )
                    .Select(t => new TenancyDto
                    {
                        Id = t.Id,
                        ApartmentName = t.Apartment!.Name,
                        PropertyName = t.Apartment.Property!.Name,
                        StartDate = t.StartDate,
                        EndDate = t.EndDate,
                        MonthlyRent = t.MonthlyRent,
                        IsOwner = t.Apartment.Property.LandlordId == userIdClaim
                    })
                    .ToListAsync();
                return Ok(tenancies);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }

        /// <summary>
        /// Creates a new tenancy for a vacant apartment.  Only the landlord may create tenancies.
        /// </summary>
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateTenancy([FromBody] Tenancy tenancy)
        {
            try
            {
                var apartment = await _context.Apartments
                    .Include(a => a.Property)
                    .FirstOrDefaultAsync(a => a.Id == tenancy.ApartmentId);
                if (apartment == null) return NotFound("Apartment not found.");
                
                var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdClaim)) return Unauthorized();
                // Determine if current user has permission to create tenancy
                bool canCreate = false;
                bool isLandlord = apartment!.Property!.LandlordId == userIdClaim;
                if (isLandlord)
                {
                    // Check landlord subscription active & approved
                    var subscription = await _context.UserSubscriptions
                        .Where(us => us.UserId == userIdClaim && us.EndDate > DateTime.UtcNow && us.IsApproved)
                        .FirstOrDefaultAsync();
                    if (subscription == null)
                    {
                        return BadRequest("Your subscription is inactive or not approved. You cannot create tenancies.");
                    }
                    canCreate = true;
                }
                else
                {
                    // Check owner assignment with write permission
                    var hasOwnerWrite = await _context.ApartmentOwners
                        .AnyAsync(o => o.ApartmentId == apartment.Id && o.OwnerId == userIdClaim && o.Permission == PermissionLevelEnum.ReadWrite);
                    // Check manager assignment with write permission
                    var hasManagerWrite = await _context.PropertyManagerAssignments
                        .AnyAsync(m => m.PropertyId == apartment.PropertyId && m.ManagerId == userIdClaim && m.Permission == PermissionLevelEnum.ReadWrite);
                    if (hasOwnerWrite || hasManagerWrite)
                    {
                        // Also ensure landlord's subscription is active and approved
                        var landlordSubscription = await _context.UserSubscriptions
                            .Where(us => us.UserId == apartment!.Property!.LandlordId && us.EndDate > DateTime.UtcNow && us.IsApproved)
                            .FirstOrDefaultAsync();
                        if (landlordSubscription == null)
                        {
                            return BadRequest("The landlord's subscription is inactive or not approved. Cannot create tenancy.");
                        }
                        canCreate = true;
                    }
                }
                if (!canCreate)
                {
                    return Forbid();
                }
                // Validate date range (start before end)
                if (tenancy.EndDate.HasValue && (tenancy.EndDate < tenancy.StartDate))
                {
                    return BadRequest("End date cannot be earlier than start date.");
                }
                // Check for overlapping tenancies on the same apartment
                var hasOverlap = await _context.Tenancies.AnyAsync(t => t.ApartmentId == tenancy.ApartmentId &&
                    // if existing tenancy has no end date, treat as ongoing
                    (t.EndDate ?? DateTime.MaxValue) >= tenancy.StartDate &&
                    (tenancy.EndDate ?? DateTime.MaxValue) >= t.StartDate);
                if (hasOverlap)
                {
                    return BadRequest("There is already a tenancy for this apartment overlapping the specified period.");
                }
                tenancy.StartDate = tenancy.StartDate.Date;
                // Audit: record who created the tenancy
                tenancy.CreatedBy = userIdClaim;
                tenancy.CreatedAt = DateTime.UtcNow;
                tenancy.IsDeleted = false;
                _context.Tenancies.Add(tenancy);
                // Update apartment status and audit
                apartment.Status = ApartmentStatusEnum.Occupied;
                apartment.UpdatedBy = userIdClaim;
                apartment.UpdatedAt = DateTime.UtcNow;
                _context.Apartments.Update(apartment);
                await _context.SaveChangesAsync();
                // Map to DTO for return
                var tenancyDto = new TenancyDto
                {
                    Id = tenancy.Id,
                    ApartmentName = apartment.Name,
                    PropertyName = apartment.Property != null ? apartment.Property.Name : string.Empty,
                    StartDate = tenancy.StartDate,
                    EndDate = tenancy.EndDate,
                    MonthlyRent = tenancy.MonthlyRent,
                    IsOwner = true // creator is always landlord or authorized agent, but flagged as owner
                };
                return CreatedAtAction(nameof(GetTenancies), new { id = tenancy.Id }, tenancyDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }

        /// <summary>
        /// Updates the maximum number of members allowed for a tenancy.  Only the landlord of the
        /// apartment or an authorized manager/owner with write permission may modify this value.
        /// </summary>
        [HttpPut("{id}/max-members")]
        [Authorize]
        public async Task<IActionResult> UpdateMaxTenancyMembers(int tenancyId, [FromBody] int maxMembers)
        {
            try
            {
                if (maxMembers <= 0)
                {
                    return BadRequest("MaxMembers must be a positive integer.");
                }
                var tenancy = await _context.Tenancies
                    .Include(t => t.Apartment)
                    .ThenInclude(a => a.Property)
                    .FirstOrDefaultAsync(t => t.Id == tenancyId);

                if (tenancy == null) return NotFound("Tenancy not found.");

                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId)) return Unauthorized();

                // Determine if user is landlord of the apartment
                bool isLandlord = tenancy.Apartment!.Property!.LandlordId == userId;
                bool canWrite = false;
                if (isLandlord)
                {
                    canWrite = true;
                }
                else
                {
                    // Check owner write permission
                    var ownerWrite = await _context.ApartmentOwners
                        .AnyAsync(o => o.ApartmentId == tenancy.ApartmentId && o.OwnerId == userId && o.Permission == PermissionLevelEnum.ReadWrite);
                    // Check manager write permission
                    var managerWrite = await _context.PropertyManagerAssignments
                        .AnyAsync(m => m.PropertyId == tenancy.Apartment.PropertyId && m.ManagerId == userId && m.Permission == PermissionLevelEnum.ReadWrite);
                    canWrite = ownerWrite || managerWrite;
                }
                if (!canWrite)
                {
                    return Forbid();
                }
                tenancy.MaxMembers = maxMembers;
                tenancy.UpdatedBy = userId;
                tenancy.UpdatedAt = DateTime.UtcNow;
                _context.Tenancies.Update(tenancy);
                await _context.SaveChangesAsync();
                return Ok(new { Message = "MaxMembers updated successfully.", TenancyId = tenancy.Id, MaxMembers = tenancy.MaxMembers });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }

        /// <summary>
        /// Extends or renews a tenancy by setting a new end date.  Only the landlord or
        /// an authorized manager/owner with write permission may perform this operation.
        /// </summary>
        [HttpPut("{id}/extend")]
        [Authorize]
        public async Task<IActionResult> ExtendTenancy(int id, [FromBody] ExtendTenancyRequest request)
        {
            try
            {
                var tenancy = await _context.Tenancies
                    .Include(t => t.Apartment!.Property)
                    .FirstOrDefaultAsync(t => t.Id == id);
                if (tenancy == null) return NotFound("Tenancy not found.");
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId)) return Unauthorized();
                // Validate new end date
                if (request.NewEndDate <= tenancy.StartDate)
                {
                    return BadRequest("New end date must be after the tenancy start date.");
                }
                // Determine if user can modify end date
                bool isLandlord = tenancy.Apartment!.Property!.LandlordId == userId;
                bool canWrite = false;
                if (isLandlord)
                {
                    canWrite = true;
                }
                else
                {
                    var ownerWrite = await _context.ApartmentOwners
                        .AnyAsync(o => o.ApartmentId == tenancy.ApartmentId && o.OwnerId == userId && o.Permission == PermissionLevelEnum.ReadWrite);
                    var managerWrite = await _context.PropertyManagerAssignments
                        .AnyAsync(m => m.PropertyId == tenancy!.Apartment.PropertyId && m.ManagerId == userId && m.Permission == PermissionLevelEnum.ReadWrite);
                    canWrite = ownerWrite || managerWrite;
                }
                if (!canWrite)
                {
                    return Forbid();
                }
                tenancy.EndDate = request.NewEndDate;
                tenancy.UpdatedBy = userId;
                tenancy.UpdatedAt = DateTime.UtcNow;
                _context.Tenancies.Update(tenancy);
                await _context.SaveChangesAsync();
                return Ok(new { Message = "Tenancy extended successfully.", TenancyId = tenancy.Id, NewEndDate = tenancy.EndDate });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }
    }
}