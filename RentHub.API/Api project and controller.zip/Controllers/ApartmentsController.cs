using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RentHub.API.Data;
using RentHub.API.Models.Entities;
using Common.Enums;
using Common.CommunicationModels;
using System.Security.Claims;

namespace RentHub.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ApartmentsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public ApartmentsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        /// <summary>
        /// Lists all apartments that are currently vacant.  Includes property and landlord info.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetApartments()
        {
            try
            {
                var apartments = await _context.Apartments
                    .Include(a => a.Property)
                    .Where(a => a.Status == ApartmentStatusEnum.Vacant)
                    .Select(a => new ApartmentDto
                    {
                        Id = a.Id,
                        Name = a.Name,
                        Type = a.Type.ToString(),
                        Price = a.Price,
                        Area = a.Area,
                        PropertyName = a.Property != null ? a.Property.Name : string.Empty,
                        LandlordName = a.Property!.Landlord != null ? a.Property.Landlord.FullName ?? string.Empty : string.Empty,
                        Status = a.Status.ToString()
                    })
                    .ToListAsync();
                return Ok(apartments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }

        /// <summary>
        /// Creates a new apartment under an existing property.  Only the property owner or
        /// delegated manager can add apartments.
        /// </summary>
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateApartment([FromBody] CreateApartmentRequest request)
        {
            try
            {
                // Ensure property exists and not soft-deleted by using FirstOrDefaultAsync to apply the query filter
                var property = await _context.Properties
                    .FirstOrDefaultAsync(p => p.Id == request.PropertyId);
                if (property == null)
                {
                    return NotFound("Property not found.");
                }

                // Get current user
                var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdClaim)) return Unauthorized();

                // Only the landlord who owns the property can add apartments
                if (property.LandlordId != userIdClaim)
                {
                    return Forbid();
                }

                // Normalize + validate apartment name
                var normalizedAptName = (request?.Name ?? "").Trim();
                if (string.IsNullOrWhiteSpace(normalizedAptName))
                {
                    return BadRequest("Apartment name is required.");
                }

                // Check uniqueness of apartment name (case-insensitive) within the same property
                var aptNameKey = normalizedAptName.ToUpper();
                var apartmentExists = await _context.Apartments.AnyAsync(a =>
                    a.PropertyId == request.PropertyId &&
                    !a.IsDeleted &&
                    a.Name != null &&
                    a.Name.Trim().ToUpper() == aptNameKey
                );

                if (apartmentExists)
                {
                    return BadRequest($"An apartment with the name '{normalizedAptName}' already exists in this property.");
                }

                // Check landlord's subscription plan limits
                var activeSubscription = await _context.UserSubscriptions
                    .Include(us => us.SubscriptionPlan)
                    .Where(us => us.UserId == userIdClaim && us.EndDate > DateTime.UtcNow)
                    .OrderByDescending(us => us.EndDate)
                    .FirstOrDefaultAsync();

                var maxApts = activeSubscription?.SubscriptionPlan?.MaxApartmentsPerProperty;
                if (maxApts.HasValue)
                {
                    var existingCount = await _context.Apartments.CountAsync(a => a.PropertyId == request.PropertyId && !a.IsDeleted);
                    if (existingCount >= maxApts.Value)
                    {
                        return BadRequest($"Maximum number of apartments per property ({maxApts.Value}) reached for your subscription.");
                    }
                }

                // Create a new apartment entity based on the request
                var apartment = new Apartment
                {
                    PropertyId = request.PropertyId,
                    Name = normalizedAptName,
                    Type = request.Type,
                    Price = request.Price,
                    Area = request.Area,
                    AdderId = userIdClaim,
                    Status = ApartmentStatusEnum.Vacant,
                    CreatedBy = userIdClaim,
                    CreatedAt = DateTime.UtcNow,
                    IsDeleted = false
                };

                _context.Apartments.Add(apartment);
                await _context.SaveChangesAsync();

                // Map to DTO for return
                var dto = new ApartmentDto
                {
                    Id = apartment.Id,
                    Name = apartment.Name,
                    Type = apartment.Type.ToString(),
                    Price = apartment.Price,
                    Area = apartment.Area,
                    PropertyName = property.Name,
                    LandlordName = property.Landlord != null ? property.Landlord.FullName ?? string.Empty : string.Empty,
                    Status = apartment.Status.ToString()
                };

                return CreatedAtAction(nameof(GetApartments), new { id = apartment.Id }, dto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }
    }
}